#!/bin/bash

# Helm Version
echo "*** helm version ***"
helm version

# Kubectl Version
echo "*** kubectl version ***"
kubectl version --kubeconfig=/home/runners/.kube/config

#Awscli Version
echo "*** aws version ***"
aws --version

#Print kubectl config
#cat /home/runners/.kube/config


# Deploy alb ingress controller

#helm repo add eks https://aws.github.io/eks-charts
#helm repo update

helm uninstall aws-load-balancer-controller -n collibradq \
--kubeconfig  /home/runners/.kube/config

# Deploy external dns

#helm repo add bitnami https://charts.bitnami.com/bitnami
helm uninstall external-dns -n collibradq \
--kubeconfig  /home/runners/.kube/config
# Move to chart folder

#cd k8s/helm/prod

# Collibra DQ Deployment

helm uninstall collibradq  -n collibradq \
--kubeconfig  /home/runners/.kube/config



# Service Account , Metrics Server , Node AutoScaler & Ingress Deployment


#helm template collibradq
#helm lint collibradq
helm uninstall  cdq01   -n collibradq \
--kubeconfig  /home/runners/.kube/config

 
