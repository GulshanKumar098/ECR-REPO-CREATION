#!/bin/bash

# Helm Version
echo "*** helm version ***"
helm version

# Kubectl Version
echo "*** kubectl version ***"
kubectl version --kubeconfig=/home/runners/.kube/config

#Awscli Version
echo "*** aws version ***"
aws --version

#Print kubectl config
#cat /home/runners/.kube/config


# Deploy alb ingress controller

helm repo add eks https://aws.github.io/eks-charts
helm repo update

helm upgrade --install aws-load-balancer-controller eks/aws-load-balancer-controller \
  -n collibradq \
  --kubeconfig  /home/runners/.kube/config \
  --set clusterName=$CDQ_EKS_CLUSTER \
  --set serviceAccount.create=false \
  --set serviceAccount.name=aws-load-balancer-controller \
  --set image.repository=602401143452.dkr.ecr.us-east-1.amazonaws.com/amazon/aws-load-balancer-controller \
  --set region=us-east-1 \
  --set vpcId=vpc-05b0f2f73946ca03e

# Deploy external dns

helm repo add bitnami https://charts.bitnami.com/bitnami
helm upgrade --install external-dns -n collibradq \
  --kubeconfig  /home/runners/.kube/config \
  --set provider=aws \
  --set aws.zoneType=public \
  --set serviceAccount.create=false \
  --set serviceAccount.name=dns \
  --set txtOwnerId=Z096812522XMKZWDMZRSM \
  --set domainFilters[0]=ae-dq-devl-floating.us.e18.c01.johndeerecloud.com \
  bitnami/external-dns

# Move to chart folder

cd k8s/helm/devl

# Collibra DQ Deployment

helm upgrade --install collibradq owldq-2022-05 -n collibradq \
--kubeconfig  /home/runners/.kube/config \
--set global.version.owl=2022.09-ADGCSILM-1386 \
--set global.version.spark=3.2.2-2022.09-ADGCSILM-1386 \
--set global.configMap.data.license_key=$CDQ_LICENSE_KEY \
--set global.web.service.type=NodePort \
--set global.metastore.enabled=false \
--set global.configMap.data.metastore_url=$CDQ_METASTORE_URL \
--set global.configMap.data.metastore_user=$CDQ_METASTORE_USER \
--set global.configMap.data.metastore_pass=$CDQ_METASTORE_PASSWORD \
--set global.web.usageMeter.pendo.accountId=JohnDeree-license \
--set global.web.usageMeter.enabled=true \
--set global.web.resources.limits.memory="4Gi" \
--set global.livy.enabled=true \
--set global.cloudStorage.s3.enableS3=true \
--set global.cloudStorage.s3.enableIAM=true \
--set global.web.replicaCount=2




# Service Account , Metrics Server , Node AutoScaler & Ingress Deployment


helm template collibradq
helm lint collibradq
helm upgrade --install cdq01  collibradq -n collibradq \
--kubeconfig  /home/runners/.kube/config \
--set autoScalerImage="k8s.gcr.io/autoscaling/cluster-autoscaler:v1.21.3" \
--set clusterName=$CDQ_EKS_CLUSTER

