#!/bin/bash
echo"**********************"
aws sts get-caller-identity
echo"**********************"
cp /home/runners/.kube/config test-config
#kubectl config set-credentials arn:aws:eks:us-east-1:713436935773:cluster/collibradq-test --exec-env=AWS_PROFILE=aws-ae-dq-devl --kubeconfig=test-config
echo "*********************"
echo "*********************"
kubectl cluster-info  --kubeconfig=test-config
echo "*********************"

